-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Май 19 2026 г., 11:41
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `u95122db_123124`
--

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--
-- Создание: Май 19 2026 г., 07:23
-- Последнее обновление: Май 19 2026 г., 07:25
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `client_id` int NOT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`client_id`, `last_name`, `first_name`, `phone`, `email`) VALUES
(1, 'Григорьев', 'Алексей', '+79161112233', 'grigoriev@example.com'),
(2, 'Морозова', 'Екатерина', '+79262223344', 'morozova@example.com'),
(3, 'Соколов', 'Дмитрий', '+79363334455', 'sokolov@example.com'),
(4, 'Кузнецова', 'Анна', '+79464445566', 'kuznetsova@example.com'),
(5, 'Васильев', 'Игорь', '+79565556677', 'vasiliev@example.com');

-- --------------------------------------------------------

--
-- Структура таблицы `favorites`
--
-- Создание: Май 19 2026 г., 07:23
-- Последнее обновление: Май 19 2026 г., 07:33
--

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE `favorites` (
  `client_id` int NOT NULL,
  `property_id` int NOT NULL,
  `added_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `favorites`
--

INSERT INTO `favorites` (`client_id`, `property_id`, `added_at`) VALUES
(1, 3, '2026-05-19 07:33:33'),
(1, 4, '2026-05-19 07:33:33'),
(2, 1, '2026-05-19 07:33:33'),
(3, 5, '2026-05-19 07:33:33'),
(4, 2, '2026-05-19 07:33:33');

-- --------------------------------------------------------

--
-- Структура таблицы `properties`
--
-- Создание: Май 19 2026 г., 07:23
-- Последнее обновление: Май 19 2026 г., 07:33
--

DROP TABLE IF EXISTS `properties`;
CREATE TABLE `properties` (
  `property_id` int NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `property_type` enum('квартира','дом','апартаменты') COLLATE utf8mb4_unicode_ci NOT NULL,
  `rooms` tinyint UNSIGNED NOT NULL,
  `area` decimal(7,2) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `realtor_id` int NOT NULL
) ;

--
-- Дамп данных таблицы `properties`
--

INSERT INTO `properties` (`property_id`, `address`, `property_type`, `rooms`, `area`, `price`, `realtor_id`) VALUES
(1, 'ул. Ленина, д. 15, кв. 45', 'квартира', 2, '56.50', '7500000.00', 1),
(2, 'пр. Мира, д. 8, кв. 12', 'квартира', 1, '38.00', '5200000.00', 1),
(3, 'ул. Садовая, д. 23', 'дом', 4, '120.00', '14500000.00', 2),
(4, 'ул. Чехова, д. 7, кв. 88', 'квартира', 3, '78.20', '11200000.00', 3),
(5, 'пер. Цветочный, д. 3', 'дом', 3, '95.00', '9800000.00', 4),
(6, 'ул. Ленина, д. 15, кв. 45', 'квартира', 2, '56.50', '7500000.00', 1),
(7, 'пр. Мира, д. 8, кв. 12', 'квартира', 1, '38.00', '5200000.00', 1),
(8, 'ул. Садовая, д. 23', 'дом', 4, '120.00', '14500000.00', 2),
(9, 'ул. Чехова, д. 7, кв. 88', 'квартира', 3, '78.20', '11200000.00', 3),
(10, 'пер. Цветочный, д. 3', 'дом', 3, '95.00', '9800000.00', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `realtors`
--
-- Создание: Май 19 2026 г., 07:23
-- Последнее обновление: Май 19 2026 г., 07:32
--

DROP TABLE IF EXISTS `realtors`;
CREATE TABLE `realtors` (
  `realtor_id` int NOT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hire_date` date NOT NULL DEFAULT (curdate())
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `realtors`
--

INSERT INTO `realtors` (`realtor_id`, `last_name`, `first_name`, `phone`, `hire_date`) VALUES
(1, 'Волкова', 'Ольга', '+79031112233', '2023-03-15'),
(2, 'Смирнов', 'Артём', '+79032223344', '2022-09-01'),
(3, 'Ершова', 'Марина', '+79033334455', '2024-01-10'),
(4, 'Фёдоров', 'Никита', '+79034445566', '2023-07-20');

-- --------------------------------------------------------

--
-- Структура таблицы `viewings`
--
-- Создание: Май 19 2026 г., 07:23
-- Последнее обновление: Май 19 2026 г., 07:33
--

DROP TABLE IF EXISTS `viewings`;
CREATE TABLE `viewings` (
  `viewing_id` int NOT NULL,
  `client_id` int NOT NULL,
  `property_id` int NOT NULL,
  `realtor_id` int NOT NULL,
  `viewing_datetime` datetime NOT NULL,
  `status` enum('запланирован','проведён','сделка','отменён') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'запланирован',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `viewings`
--

INSERT INTO `viewings` (`viewing_id`, `client_id`, `property_id`, `realtor_id`, `viewing_datetime`, `status`, `created_at`) VALUES
(1, 1, 1, 1, '2026-05-25 10:00:00', 'запланирован', '2026-05-19 07:33:25'),
(2, 2, 1, 1, '2026-05-25 15:00:00', 'проведён', '2026-05-19 07:33:25'),
(3, 3, 2, 1, '2026-05-26 11:00:00', 'сделка', '2026-05-19 07:33:25'),
(4, 4, 3, 2, '2026-05-27 13:30:00', 'сделка', '2026-05-19 07:33:25'),
(5, 5, 4, 3, '2026-05-28 09:00:00', 'отменён', '2026-05-19 07:33:25'),
(6, 1, 5, 4, '2026-05-29 12:00:00', 'запланирован', '2026-05-19 07:33:25'),
(7, 2, 3, 2, '2026-05-30 11:00:00', 'проведён', '2026-05-19 07:33:25');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`client_id`,`property_id`),
  ADD KEY `property_id` (`property_id`);

--
-- Индексы таблицы `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`property_id`),
  ADD KEY `idx_property_realtor` (`realtor_id`),
  ADD KEY `idx_property_type` (`property_type`),
  ADD KEY `idx_property_price` (`price`);

--
-- Индексы таблицы `realtors`
--
ALTER TABLE `realtors`
  ADD PRIMARY KEY (`realtor_id`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Индексы таблицы `viewings`
--
ALTER TABLE `viewings`
  ADD PRIMARY KEY (`viewing_id`),
  ADD UNIQUE KEY `unique_viewing_slot` (`property_id`,`viewing_datetime`),
  ADD KEY `idx_viewing_datetime` (`viewing_datetime`),
  ADD KEY `idx_viewing_client` (`client_id`),
  ADD KEY `idx_viewing_realtor` (`realtor_id`),
  ADD KEY `idx_viewing_status` (`status`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `properties`
--
ALTER TABLE `properties`
  MODIFY `property_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `realtors`
--
ALTER TABLE `realtors`
  MODIFY `realtor_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `viewings`
--
ALTER TABLE `viewings`
  MODIFY `viewing_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `properties_ibfk_1` FOREIGN KEY (`realtor_id`) REFERENCES `realtors` (`realtor_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `viewings`
--
ALTER TABLE `viewings`
  ADD CONSTRAINT `viewings_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `viewings_ibfk_2` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `viewings_ibfk_3` FOREIGN KEY (`realtor_id`) REFERENCES `realtors` (`realtor_id`) ON DELETE RESTRICT ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
